import pyttsx3
import webbrowser
import speech_recognition as sr
import pyjokes
import pyautogui
import wikipedia
import os
engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voice',voices[0].id)
engine.setProperty('rate',150)
engine.setProperty('pitch',1.0)

def speak(audio):
    engine.say(audio)
    engine.runAndWait()
    print(audio)

def takecommand():      
    r = sr.Recognizer()
    with sr.Microphone() as source:
        speak("listening")
        print("listening...")
        audio = r.listen(source)
        try:
            print("recognizing")
            query = r.recognize_google(audio,language='en-in')
        except:
            speak("mei behra hu")
            return "none"
        return query    
    
while True:
    q = takecommand().lower()
    if "your name" in q:
        speak("i am tom ")

    elif "your age" in q:
        speak(" i am still young")

    elif "open youtube" in q:
        speak("opening youtube")
        webbrowser.open("http://www.youtube.com")

    elif "open google" in q:
        speak("opening  google")
        webbrowser.open("http://www.google.com")

    elif "where you live" in q:
        speak("in your heart")

    elif "your girlfriend name" in q:
        speak("Toodles Galore")

    elif "exit"in q:
        speak (" i am going bye")
        exit()

    elif "joke" in q:
        a = pyjokes.get_joke()
        print(a)
        speak(a)

    elif 'open notepad' in q:
        speak("ok opening notepad")
        os.system("C:\\Windows\\notepad.exe") 

    elif 'volume up'in q:
        speak("ok volume up")
        pyautogui.press("volumeup")

    elif 'volume down'in q:
        speak("ok volume down")
        pyautogui.press("volumedown")

    elif 'volume mute' in q:
        speak("ok muting")
        pyautogui.press("volumemute")

    elif 'wikipedia' in q:
        query = q.replace("wikipedia","")
        result = wikipedia.summary(query,sentences = 3)
        print(f"according to wikipedia{result}") 
        speak(f"according to wikipedia{result}")    
